[WIP] Lab code using Chainer
---
