for i in range(10):
    if i == 5:
        break
    print(i)
print("EOP")
