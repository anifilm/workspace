def test(t):
    print(x)
    t = 20
    print ("In Function :", t)

x = 10
test(x)
print (t)
