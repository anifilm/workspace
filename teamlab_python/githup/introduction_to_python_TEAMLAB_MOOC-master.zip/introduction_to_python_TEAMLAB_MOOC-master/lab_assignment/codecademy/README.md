## Codecademy - Python 제출하기

Codecademy에서 아래의 파이썬 과정을 등록해서 실시한다.
- https://www.codecademy.com/learn/learn-python

아래와 같이 자신의 아이디와 python 결과를 함께 캡쳐하여 아래와 같이 표시한다.

![](codecademy.PNG)
